package net.sf.jsqlparser.statement.fuzzy.domain;

public abstract class OrderedDomain {
  
    public abstract String getType();
    public abstract String getLowerBound();
    public abstract String getUpperBound();

}