DROP SCHEMA IF EXISTS information_schema_fuzzy CASCADE;
