mysql -u root < infoguia_esquema.sql

mysql -u root < infoguia_categorias.sql

mysql -u root < infoguia_ciudades.sql

mysql -u root < infoguia_ciudad_estado.sql

mysql -u root < infoguia_empresas.sql

mysql -u root < infoguia_dataempresas.sql

mysql -u root < infoguia_estados.sql

mysql -u root < infoguia_paginacioncategorias.sql

mysql -u root < infoguia_secciones.sql

mysql -u root < infoguia_urbanizaciones.sql


